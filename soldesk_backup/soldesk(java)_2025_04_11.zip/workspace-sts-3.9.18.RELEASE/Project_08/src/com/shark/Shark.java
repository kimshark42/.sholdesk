package com.shark;

public class Shark {
	
	String name;
	int age;
	String hobby;
	
	void eat(String food) {
		System.out.println(name + "가 " + food + "을 먹습니다" + " 와그작 와그작");
	}
	int swim() {
		System.out.println(name + "가 따이함");
		return 100;
	}
	int add(int a, int b) {
		int sum = a + b;
		return sum;
	}
	
//	js
//	생성장 함수 오버로딩
	public Shark() {
		
	}
	public Shark(int age, String name, String hobby) {
		this.age = age;
		this.name =name;
	}
	
//	생성자 함수라고 함 종류도 다 정해줘야됨
	public Shark(int age, String name) {
		this.name = name;
				this.age = age;
	}
}
