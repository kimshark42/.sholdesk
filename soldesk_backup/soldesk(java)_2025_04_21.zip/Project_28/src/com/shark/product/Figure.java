package com.shark.product;

//상속 (super)
//자식(Drink)의 생성자 함수에서 부모(Product)의 생성자 호출
public class Figure extends Product{
	public Figure(String xx, int yy) {
		super(xx, yy);
	}
}
