/* 12면체 */
var random3;
random3 = Math.floor(Math.random() * 11) + 2; //2 ~ 12 까지 범위 내에서 랜덤하게 숫자 하나 뽑기.
var s3 = "따이를 굴려( " + random3 + " ) 이 나왔습니다";
document.write(s3);

/* 100면체 */
var random4;
random4 = Math.floor(Math.random() * 99) + 1; //1 ~ 100 까지 범위 내에서 랜덤하게 숫자 하나 뽑기.
var s4 = "따이를 굴려( " + random4 + " ) 이 나왔습니다";
document.write(s4);