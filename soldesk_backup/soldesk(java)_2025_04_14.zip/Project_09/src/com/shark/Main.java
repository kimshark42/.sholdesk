package com.shark;

public class Main {

	public static void main(String[] args) {
		// Character Player =new Character();
		Character player = new Character("김상어",120,10,"상어");
		
		//Monster slime = new slime("슬라링",12,2);
//		Monster slime = new slime("슬라링",12,2);
		player.info();
//		slime.info();

	}

}
