
//public 은 클래스를 지정하는것 class의 main (이라는)함수
//자바에서는 main메소드는 한군데만 지정시켜야됨
//ctrl+alt+아래  줄복사 똑같음
//java에서는 클래스명과 파일명은 늘 똑같아야됨

public class main {
	public static void main(String[] args) {
		System.out.println("따이");
	}
}
