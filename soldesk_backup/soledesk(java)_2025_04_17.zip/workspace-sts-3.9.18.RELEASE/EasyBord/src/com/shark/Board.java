package com.shark;

import java.util.ArrayList;
import java.util.Scanner;

public class Board {
//		루프문에 존재하면 매번 새 집을 만들기 때문에 멤버변수에 오면 좋음 (최적화)
	Scanner sc = new Scanner(System.in);
	ArrayList<Post> ps = new ArrayList<>();
	int saveNo = 0;
	
	void run() {

		xx:
		while(true) {
			// 메뉴 선택하게 하기
			System.out.println("crud 1.쓰기 2.읽기 3. 리스트 4.수정 5.삭제 e.프로그램 종료");
			String cmd = sc.next();
			switch(cmd) {
			case"1":
				System.out.println("쓰기 메뉴");
				System.out.println("제목: ");
				String title = sc.next();
				System.out.println("본문: ");
				String content = sc.next();
				System.out.println("작성자: ");
				String writer = sc.next();
				saveNo = saveNo +1;
				Post p = new Post(title,content,writer,saveNo);
				ps.add(p);
				break;
			case"2":
				System.out.println("읽기 메뉴");
				// 몇번글을 읽을지 물어보기
				System.out.println("몇번 글을 읽을까요?");
				cmd = sc.next();
				
				// 해당 글을 찾기
				for(int i=0;i<ps.size();i++) {
					Post post = ps.get(i);
					int postNo = post.no;
					String postStringNo = postNo+"";  // -> "숫자랑 문자랑 합치면 문자열이 됨"
//					if(postStringNo == cmd) { <- 이렇게 쓸수 있긴 한데 가능하면 밑 방법으로 쓸것
					if(postStringNo.equals(cmd)) {  // 해당 글을 찾음
						System.out.println(post.no+".글번호"+" 글 내용:"+post.content+" 작성자:"+post.writer);						
					}
				}
				break;
			case"3":
				System.out.println("리스트 메뉴");
//				for(int i=0;i<ps.size();i++) //같은거임
				for(int i=0;i<ps.size();i=i+1) {
//					위에서 썼던 변수이름은 못씀
					String t = ps.get(i).title;
					String c = ps.get(i).content;
					String w = ps.get(i).writer;
					int no = ps.get(i).no;
					System.out.println("글번호: "+no+"제목: "+t+" 작성자: "+w);
				}
				break;
			case"4":
				System.out.println("수정 메뉴");
				// Todo
				// 수정할 글 번호 입력받기
				System.out.println("몇번 글을 읽을까요?");
				cmd = sc.next();
				
				//해당 글 가져오기
				for(int i=0;i<ps.size();i++) {
					Post post = ps.get(i);
					int postNo = post.no;
					String postStringNo = postNo+"";  // -> "숫자랑 문자랑 합치면 문자열이 됨"
//					if(postStringNo == cmd) { <- 이렇게 쓸수 있긴 한데 가능하면 밑 방법으로 쓸것
					if(postStringNo.equals(cmd)) {  // 해당 글을 찾음
						// 바꿀 내용 입력하기
						System.out.println("바꾸실 내용은? :");
//						String newContent = sc.next();
						post.content = sc.next();
					}
				}
				
				
				// 내용을 기존 번호에 덮어쓰기
				
				break;
			case"5":
				System.out.println("삭제 메뉴");
				// 삭제할 글 번호 입력받기
				System.out.println("몇번 글을 읽을까요?");
				cmd = sc.next();
				
				// 글 리스트에서 삭제할 글 찾기
				int searchNo = 0; // -> 지역변수 취급이기때문에 초기값을 넣어야됨(근데 지금은 그냥 변수 만들면 초기값 넣는게 좋음)
				for(int i=0;i<ps.size();i++) {
					Post post = ps.get(i);
					int postNo = post.no;
					String postStringNo = postNo+"";  // -> "숫자랑 문자랑 합치면 문자열이 됨"
//					if(postStringNo == cmd) { <- 이렇게 쓸수 있긴 한데 가능하면 밑 방법으로 쓸것
					if(postStringNo.equals(cmd)) {  // 해당 글을 찾음
//						글찾기 할때 썻던 함수를 고대로 쓰되 바로 삭제하면 안되는 이유
//						글을 바로 지워버리면 글 위치가 바뀌여버리기때문에
						// 인덱스 i 를 기억해 놓기
						searchNo = i;
//						break;  // -> 만약 데이터가 300만개(무지막지하게 많이) 있을때 지울 데이터를 찾고 나서 반복할 필요가 없을때 간단하게 break문을 넣으면 됨
					}
				}
				// 삭제
				ps.remove(searchNo);
				break;
			case"e":
				System.out.println("프로그램을 종료합니다");
				break xx;
			}
		}
	}
}
