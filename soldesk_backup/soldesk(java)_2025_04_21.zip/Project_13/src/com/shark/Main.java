package com.shark;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("============================================");
		System.out.println("================= 따이한 수족관 ================");
		System.out.println("============================================");
		//ctrl + shift + o(영문자). 자동 임포트.
		kiosk p1 = new kiosk("상어콘",500);
		kiosk p2 = new kiosk("청새치 와플",1000);
		kiosk p3 = new kiosk(3000,"따이 철판구이");
		
		Scanner sc = new Scanner(System.in);
		String cmd;
		loop_a:
		while(true) {
			System.out.print("명령:[1.음료/2.디저트/e.종료]");
			cmd = sc.next();
			switch(cmd) {
			case "1":
				System.out.println("==================================");
				System.out.println("=========== 음료 리스트 =============");
				System.out.println("==================================");
				p1.info();
				
		p2.info();
				loop_b:
				while(true) {
					System.out.print("명령:[1.상어콘/2. 청새치 와플/x.이전메뉴]");
					cmd = sc.next();					
					switch(cmd) {
					case "1":
						System.out.println("상어콘이 1개 선택됐습니다.");
						break;
					case "2":
						System.out.println("청새치 와플이 1개 선택됐습니다.");
						break;
					case "x":
						break loop_b;
					}
				}
				
				break;
			case "2":
				System.out.println("==================================");
				System.out.println("============ 디저트 리스트 ===========");
				System.out.println("==================================");
				p3.info();				
				break;
			case "e":
				break loop_a;
			}
		}
		System.out.println("프로그램 종료");
	}

}
