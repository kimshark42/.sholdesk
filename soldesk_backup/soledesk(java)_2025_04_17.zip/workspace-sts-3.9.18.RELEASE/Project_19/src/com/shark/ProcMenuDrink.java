package com.shark;

public class ProcMenuDrink {
	public void run() {
		yy:
		while(true) {
//			메뉴출력
//			Kiosk 클래스에서 미리 static 키워드를 이용해 주소를 만들어 놨기 때문에 쓸수 있음
			Kiosk.p1.info();
			Kiosk.p2.info();
			Kiosk.p3.info();
			
			System.out.println("[1.상어🦈 소다/2.고래상어🐋 에이드/3,바부고래🐳 아포카토/x.이전 메뉴로]");
			
			System.out.println("");
//			cmd 까지는 오바긴 한데 통일성 있게 해놓은것
			Kiosk.cmd = Kiosk.sc.next();
			switch(Kiosk.cmd) {
			case"1":
				System.out.println("상어🦈 소다가 선택되었습니다");
//				Product x = new Product("상어소다",500);
				Kiosk.basket.add(Kiosk.p1);
				break;
			case"2":
				System.out.println("고래상어🐋 에이드가 선택되었습니다");
				break;	
			case"3":
				System.out.println("바부고래🐳 아포카토가 선택되었습니다");
				break;	
			case"x":
				System.out.println("이전 메뉴로 돌아갑니다");
				break yy;	
			}
		}
	}
}
