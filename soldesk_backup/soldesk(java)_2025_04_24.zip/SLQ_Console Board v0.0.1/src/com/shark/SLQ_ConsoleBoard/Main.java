package com.shark.SLQ_ConsoleBoard;

public class Main {
	public static void main(String[] args) {
		Board b = new Board();
		b.run();
	}
}
