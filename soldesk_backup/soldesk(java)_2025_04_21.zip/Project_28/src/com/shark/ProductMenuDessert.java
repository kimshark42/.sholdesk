package com.shark;

import com.shark.product.Product;
import com.shark.util.Cw;

public class ProductMenuDessert {
	public static void run() {
		for(Product p:KioskObject.products) { // 메뉴출력
			Cw.wn(p.name);
		}
		yy:
		while(true) {
			Cw.wn("[1.징오징오먹물 와플🦑/x.이전 메뉴로]:");
			KioskObject.cmd = KioskObject.sc.next();
			switch(KioskObject.cmd) {
			case"1":
				Cw.wn(KioskObject.products.get(2).name+"가 선택되었습니다.");
				Order n = new Order(KioskObject.products.get(2));
//				KioskObject.basket.add(new Order(KioskObject.products.get(2))); //오더 추가 <- 1번 방식
				KioskObject.basket.add(n); // 오더 추가 <- 2번 방식
				break;
			case"x":
				Cw.wn("이전 메뉴로 이동합니다.");
				break yy;
			}
		}
	}
}
