package com.shark;

public class Main {
	public static void main(String[] args) {
		Rps_03 r = new Rps_03();
		r.run();
	}
}