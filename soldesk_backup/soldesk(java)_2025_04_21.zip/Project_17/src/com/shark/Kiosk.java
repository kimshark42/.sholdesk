package com.shark;

import java.util.ArrayList;
import java.util.Scanner;

public class Kiosk {
	ArrayList<Product>basket = new ArrayList<Product>();
	Scanner sc = new Scanner(System.in);
	Product p1 = new Product("상어 소다",500);
	Product p2 = new Product("고래 상어 에이드",1000);
	Product p3 = new Product("바부고래 아포카토",3000);
	String cmd;
	
	void run() {
		xx:
		while(true) {
			System.out.println("명령 입력[1.음료 선택/2.디저트 선택/e.프로그램 종료]:");
			cmd = sc.next();
			switch(cmd) {
			case"1":
				yy:
				while(true) {
//					메뉴출력
					p1.info();
					p2.info();
					p3.info();
					
					System.out.println("[1.상어 소다/2.고래상어 에이드/3.바부고래 아포카토/x.이전메뉴로]:");
					
					System.out.println("");
					cmd = sc.next();
					
					switch(cmd) {
					case"1":
						System.out.println("상어 소다가 선택되었습니다");
//						Product x = new Product("상어 소다",500);
						
						basket.add(p1);
						break;
					case"2":
						System.out.println("고래상어 에이드가 선택되었습니다");
						break;
					case"3":
						System.out.println("바부 고래 아포카토가 선택되었습니다");
						break;
					case"x":
						System.out.println("이전 메뉴 이동");
						break yy;
					}
				}
			case"2":
				System.out.println("2번");
			case"e":
				System.out.println("프로그램 종료");
				int count = basket.size();
				
				System.out.println("장바구니에 담긴 상품 갯수:"+count);
				
				int sum = 0;
				for(int i=0;i<basket.size();i=i+1) {
					sum = sum + basket.get(i).price;
				}
				
				System.out.println("계산하실 금액은: "+sum+"안 입니다.");
				
				break xx;
			}
		}
	}
}
