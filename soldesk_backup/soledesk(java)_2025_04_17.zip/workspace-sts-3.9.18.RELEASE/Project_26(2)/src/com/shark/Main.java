package com.shark;

import java.util.ArrayList;

import com.shark.util.So;

public class Main {
	public static void main(String[]args) {
		// 게임 오브젝트를 로딩
		
		Character c = new Character("김상어",4,47);
		Character x = new Character("청새치",8,100);
		
		GameObject go;
		
		// 아버지 - 자식
		// 형 변환
		// type 변환
		// Character 클래스가 GameObject 로 바뀌였다
		// -> 전부 같은 이야기
		
		go = (Character)x; // <- 자동변환, 묵시적 타입 변환
//		여기서 괄호 + 클래스명 + 괄호 + 변수 <- 이게 형 변환 명령어
		
		// 1. 아버지 양복을 훔처 입어서(형 변환) 아버지 객체로 취급함
		// 2. 다만 아버지 객체로 변신하여 취급됬기 때문에 자신의 행동은 할수 없음
		// ex) 본인의 public Character (String name, int age){
//		              this.name = name;
//		              int.age = age;
//	                  }
		// 이런 멤버변수가 있다 쳐도 쓰지 못함
//		따라서 Character cc = go; <- 이런건 에러가 남
		// 3. 자신의 변수나 함수를 쓰려면 변신을 풀어야함
		Character cc = (Character)go;   // <- 이런식으로 자기 형으로 형 변환 해서 돌아가야됨
		System.out.println(cc.hp);   // 그래서 돌아가고 난 다음엔 이렇게 자신의 멤버변수를 쓸수 있게됨
		
		Sword s = new Sword("단검",2,100,50,70);
//		LongSword l = new LongSword("장검",3,150,100,70);
		
//		할아버지형 리스트에 손자, 아들, 본인 다 넣을수 있음 (상속의 중요한 특성)
		ArrayList<GameObject> gs = new ArrayList<GameObject>();
		gs.add(c);  // 이때에도 자동 형 변환이 일어남
		gs.add(s);  // 이때에도 자동 형 변환이 일어남
//		gs.add(l);  // 이때에도 자동 형 변환이 일어남
		for(GameObject o : gs) {
			So.ln(o.name);
	}
}	
}

//물어볼꺼 -> color.java 는 뭔가
//-> cmd 콘솔에 색 넣는거
//상속에서 아버지 양복을훔처 입어서 형 변환을 한다고 했는데 그게 위장이라는 뜻인가(원형이 존재하는 형태) 아니면 덮어 씌운다는 뜻인가
//-> 원형이 존재한다는 뜻, 나중에 변신을 풀때 중요함
//오버라이딩 -> 부모함수를 자식들이 재정의 해서 쓴다고 했는데 부모 함수에 final 이 붙어버리면 어떻게 되는가
// -> 2025_04_15 내일 설명, 다만 final 이 붙으면 재정의 자체가 안됨