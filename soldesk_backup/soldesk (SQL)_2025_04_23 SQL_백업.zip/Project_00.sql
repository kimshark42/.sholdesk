CREATE DATABASE shark default CHARACTER SET UTF8MB4;   -- 이건 기본 디비(데터 베이스)를 생성하는것
/* 이 프로그램은 사실상 개발도구가 아님, 메모장 같은거 여기 있는 모든 텍스트를 지워도 컴퓨터에는 남아 있음*/

use shark;

create table visit_count(	#테이블 만들기. 칼럼(또는 필드 또는 열이름)은 딸랑 한개.
	count int
);
drop table visit_count;
show tables; 
  
select * from visit_count;
  
insert into visit_count values(0);	#데이터를 한 줄 넣기

update visit_count set count=count+1;

delete from visit_count;