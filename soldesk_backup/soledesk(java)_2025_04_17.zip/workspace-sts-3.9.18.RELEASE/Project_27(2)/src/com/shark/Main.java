package com.shark;

import java.util.ArrayList;
import com.shark.util.So;

public class Main {
	public static void main(String[] args) {
		// 게임 오브젝트를 로딩
		Character c = new Character("김상어",4,47);
		Sword s = new Sword("단검",2,100,50,70);
		Sword l = new Sword("장검",3,150,100,70);
		
		// 형변환 코드
//		c.name = "바부고래";
		((GameObject)c).name = "바부고래";
		
//		((GameObject)c).attack;  // 손자가 아버지로 형변환, 대신 자기 변수를 쓸수 없음
//		((GameObject)c).slash();  //손저가 아버지로 형변환, 대신 자기 변수를 쓸수 없음
		
		////  형변환은 가족끼리(상속을 거칠수 있는 것들)만 가능  ////
		// 각자 강제 형변환 후, 할아버지 변수(GameObject.java)에 대입했을떄 나오는것
		GameObject g1 = (GameObject)s;  // 손자(Sword)가 할아버지로 형변환함
		GameObject g2 = (GameObject)c;  // 작은 아버지(Character.java)가 할아버지로 형변환함
		
		// 그냥 할아버지 변수에 대입해도 자동 형변환이 가능함
		GameObject g3 = s;  // 손자(Sword)가 할아버지로 형변환함
		GameObject g4 = c;  // 작은 아버지(Character.java)가 할아버지로 형변환함
		
		// 다만 자신의 변수는 쓸수 없음
//      ex)
//		g4.attack;
//		g4.hp;
		
		ArrayList<GameObject> gf = new ArrayList<>();
		gf.add(g3);
		gf.add(g4);
		
		// 만약 자신의 변수(함수)를 쓰고 싶다면?
		// 원형(자신)으로 돌아가야됨 [뺏어간 아빠옷 다시 옷장에 고이 넣어 둬야됨]
		Sword shortSword = (Sword)g3; // -> 손자 클래스가 할아버지 정장 옷장에 집어 넣음(원래대로 돌아감)
//		shortSword.attack(); // 이런식으로 자신의 함수(또는 변수)를 다시 쓸수 있게 됨
		
		if(g3 instanceof Sword) {
			So.ln("임마 원래 검임");
	    }
		if(g4 instanceof Character) {
			So.ln("임마 원래 캐릭터임");
        }
		
		// 할아버지형 리스트에 손자, 아들, 본인 다 넣을수 있움 (상속의 중요 특성)
		ArrayList<GameObject> gs = new ArrayList<>();
		gs.add(c);
		gs.add(s);
		gs.add(l);
		for(GameObject o : gs) {
			So.ln(o.name);
			if(o instanceof Sword) {
				System.out.println(o.name+"의 공격력은"+((Sword)o).attack);
			}
			if(o instanceof Character) {
				System.out.println(o.name+"의 체력은"+((Character)o).hp);
			}
		}
		int n = 1 + ((Sword)gs.get(2)).attack;
		So.ln("공격력"+n);
		
		// 1. 형변환을 했다고 해서 주소값이 바뀌거가 하지는 않음
		GameObject xx = c;
		
		System.out.println(System.identityHashCode(c));
		System.out.println(System.identityHashCode(xx));
		
		// 2. 부모객체를 자식으로 형변환은 못함
		
//		Item x = new Item();
//		아래 주석 풀고 테스트하면 Class Cast Exception 남
//		사유 -> 부모객체를 자식으로는 형변환 살수 없음
//		추가로 형제끼리도 형변환이 불가능함
//		본체가 Item 인데 자식(Sword)로 형변환하는것은 불가능함
//		
//		Sword ss = (Sword)x;
//		3. 본체가 손자(Sword) 인데 아버지나 할아버지로 형 변환을 하고 다시 자기 모습으로 형변환은 가능함
//		
//		3-1. 아래 코드도 본체가 손자(Sword)인데 아버지로 (자동)형변환 한것임
//		Item z = new Sword();
//		위 코드는 아래 3-2 로 바꿔서 처리한것과 같음
//		3-2
//		Sword xxx = new Sword();
//		Item yyy = (Item)xxx;  //명시적 형 변환, 업 캐스팅 (자식 > 부모)
//		Item yyy = xxx;  //자동 형 변환, 업 캐스팅 (자식 > 부모)
		////3-3. 다운캐스팅 예시 코드. 
//		Sword sss = (Sword)yyy;	//다운 캐스팅 (부모 > 자식)
//		Sword ss = y;	//다운 캐스팅 (부모 > 자식) << 이건 에러남.
	}		
}
