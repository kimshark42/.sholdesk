package com.shark;

public class Character extends GameObject{
//	String name;
	int hp;
	int attack;
}
