package com.shark;

public class Main {
	public static void main(String[] args) {
		
		Shark shark=new Shark();
		shark.name= "김상어";
		
		shark.eat("당신");

//		Shark babu = new Shark();
//		babu.age = 10;
//
		Shark whileShark = new Shark(34, "고래상어");
//		int sum = whileShark.add(1, 2);
//		System.out.println(sum);
	}

}
