//1번 static을 사용하여 어디서든 동일한 장바구니를 공유하도록 설계
//컴퓨터가 코드 읽는 순서) 사용자가 메뉴 선택 -> 외부 클래스에서 음료 처리 -> 종료시 결제정보 출력

package com.shark;

import java.util.ArrayList;
import java.util.Scanner;

public class Kiosk {
	ProcMenuDrink procMenuDrink = new ProcMenuDrink();
	
//	공용으로 쓰기 때문에 basket 변수도 static 변수로 넣어둠 중요
	public static ArrayList<Product>basket = new ArrayList<Product>();
	
	public static Scanner sc = new Scanner(System.in);
	
//	static 을 걸어서 다른곳에서도 쓸수 있게끔 함
//	대신 쓰고싶으면 해당 클래스 + .뒤에 온 (예를 들면 p1) 으로 지정해줘야함
	public static Product p1 = new Product("상어 소다🦈",500);
	public static Product p2 = new Product("고래상어🐋 에이드",1500);
	public static Product p3 = new Product("바부고래🐳 아포카토",2000);
	public static String cmd;
	
	void run() {
		Display.title();
		xx:
		while(true) {
			System.out.println("명령 입력[1.음료선택/2.디저트 선택/e.프로그램 종료]:");
			cmd = sc.next();
			switch(cmd) {
			case"1":
				procMenuDrink.run();
				break;
			case"2":
				System.out.println("2번");
				break;
			case"e":
				System.out.println("프로그램을 종료합니다");
				
				int count = basket.size();
				
				System.out.println("장바구니에 담긴 상품 갯수:"+count);
				
				int sum = 0;
//				for(int i=0;i<basket.size();i=i+1) {
//					sum = sum + basket.get(i).price;
				for(Product b:basket) {
					System.out.println(b);
					sum = sum + b.price;
				}
				System.out.println("계산하실 금액은"+sum+"안 입니다.");
				break xx;
			}
		}
	}
}


//2번 코드 각 인스턴스가 자기만의 장바구니와 입력도구를 가짐
//컴퓨터가 코드를 읽는 순서) 사용자가 메뉴 선택 -> 즉시 음료 메뉴로 진입 -> 직접 상품을 고르고 장바구니에 담음
//-> 종료시 결제정보 출력

/*************************************************************************
 package com.shark;

import java.util.ArrayList;
import java.util.Scanner;

public class Kiosk {
	ArrayList<Product> basket = new ArrayList<Product>();
	//자동임포트 단축키: ctrl+shift+o(영문자O)
	Scanner sc = new Scanner(System.in);
	Product p1 = new Product("상어 소다",500);
	Product p2 = new Product("고래상어 에이드",1500);
	Product p3 = new Product("바부고래 아포카토",2000);
	String cmd;
	
	void run() {
		Display.title();
		xx:while(true) {
			System.out.print("명령 입력[1.음료선택/2.디저트선택/e.프로그램종료]:");
			cmd = sc.next();
			switch(cmd) {
			case "1":
				yy:while(true) {
					//메뉴출력
					p1.info();
					p2.info();
					p3.info();
					
					System.out.println("[1.상어 소다/2.고래상어 에이드/3.바부고래 아포카토/x.이전메뉴로]");
					System.out.println("");
					cmd = sc.next();
					switch(cmd) {
					case "1":
						System.out.println("상어 소다가 선택되었습니다");
						
//						Product x = new Product("상어소디",500);
//						basket.add(x);
						basket.add(p1);
						
						break;
					case "2":
						System.out.println("고래상어 에이드가 선택되었습니다");
						break;
					case "3":
						System.out.println("바부고래 아포카토가 선택되었습니다");
						break;
					case "x":
						System.out.println("이전 메뉴 이동합니다");
						break yy;
					}
				}
			case "2":
				System.out.println("2번");
				break;
			case "e":
				System.out.println("프로그램을 종료합니다");
				
				int count = basket.size();
				System.out.println("장바구니에 담긴 상품 갯수:"+count);
				
				int sum = 0;
				for(int i=0;i<basket.size();i=i+1) {
					sum = sum + basket.get(i).price;
				}
				System.out.println("계산하실 금액은 :"+sum+"안 입니다.");
				
				break xx;
			}
		}		
	}
}
***********************************************************************/
