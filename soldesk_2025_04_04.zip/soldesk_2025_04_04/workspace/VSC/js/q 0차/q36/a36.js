function addSharkAndInputText(){
    var inputText = prompt("값 입력:");
    document.write("상어"+inputText);
}

addSharkAndInputText();