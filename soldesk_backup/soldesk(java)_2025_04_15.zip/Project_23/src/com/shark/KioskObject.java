package com.shark;

import java.util.ArrayList;
import java.util.Scanner;

public class KioskObject {
	public static ArrayList<Order> basket = new ArrayList<>(); //주문들
	public static ArrayList<Product> products = new ArrayList<>(); //상품들
	public static Scanner sc = new Scanner(System.in);
	public static String cmd;
	
	public static void productLoad() {
		products.add(new Product("상어 소다",500));  // 상품목록 처리
		products.add(new Product("고래상어 에이드",1500));
		products.add(new Product("바부고래 아포카토",2000));
		products.add(new Product("징어먹물 와플",1500));
//		products.add(new Product("징어먹물 와플",1500));
	}
}
