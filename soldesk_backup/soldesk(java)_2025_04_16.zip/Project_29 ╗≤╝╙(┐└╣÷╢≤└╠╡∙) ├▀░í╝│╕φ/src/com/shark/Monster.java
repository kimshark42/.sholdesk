package com.shark;

public class Monster {
	int hp;
	int attack;
	String name;
	
	void attack(Player p) {
//		System.out.println("용사님의 강력한 일격!!");
	}
}
