// 클래스
var sharkName = "김상어";
var sharkAge = "4";
var sharkLevel = "47";

// 이런 변수를 일일이 만들기 힘들기 때문에
// 한번에 모아두는 코드를 class 라고함
// java 에서는 이걸 기반으로 씀

// class 로 표기하기 위해 함수 이름을 첫글자는 반드시 대문자로 씀
function Shark(){
    // 나중에 여기다가 변수 추가가 가능함
    this.name = "";
}