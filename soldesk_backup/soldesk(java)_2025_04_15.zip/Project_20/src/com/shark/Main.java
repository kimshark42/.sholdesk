package com.shark;

import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
//		일반적인 for문
		ArrayList<String>animals = new ArrayList<>();
		animals.add("김상어");
		animals.add("고래상어");
		animals.add("청새치");
		
		for(int i=0;i<animals.size();i=i+1) {
			System.out.println(animals.get(i));
		}

		//		향상된 for문(for-each라고도 함)
//		변수는 하나의 값만 지정이 가능함 그래서 몇싶 몇백개의 변수를 지정해야 될때는 끔찍하게 많은 변수를 지정해야됨
//        for문은 반복문인데 밑 처럼 하면 알아서 첫번째 변수를 꺼내줌 		
		for(String x:animals) {
			System.out.println(x);
		}
		int a[]= {1,2,3};
		for(int n:a) {
			System.out.println(n);
		}
		Shark shark1 = new Shark("김상어",4);
		Shark shark2 = new Shark("고래 상어",34);
		ArrayList<Shark>sharks = new ArrayList<>();
		sharks.add(shark1);
		sharks.add(shark2);
		for(Shark x:sharks) {
			
			System.out.println("이름:"+x.name);
			
			System.out.println("나이:"+x.age);			
		}
	}
}
