package com.shark;

import java.util.Scanner;

import com.shark.*;
import com.shark.util.Color;
import com.shark.util.Cw;

public class Display {
	public static Scanner sc = new Scanner(System.in);
	public static String cmd = sc.next();
	// title.버전 제작
	
	String x = "x";
	// 위에 라인 뭐 찍을지 만들어주는 함수
	final public static String DOT = "🦐🐟";
	final public static int DOT_COUNT = 47;
	final public static void line() {
		for(int i=0;i<DOT_COUNT;i++) {
			Color.sum(Color.BRIGHT_BLUE, DOT);
		}
		Cw.wn();
	}
//	위에 쓰던 DOT 갯수 조절
	public static void dot(int n) {
		for(int i=0;i<n;i++) {
			Color.sum(Color.BLUE, DOT);
		}
	}
	// title 출력
	public static void title() {
		line();
		dot(10);
		Color.sum(Color.BLUE, "따이한 수족관 (v."+Board.VERSION+"by kim.shark)");
		dot(10);
		Cw.wn();
		line();
	}
}
