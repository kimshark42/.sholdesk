package com.shark;

import com.shark.util.Cw;

public class ProductMenuOptionHotCold {
	public static void run() {
		loop:
		while(true) {
			Cw.wn("[1.Hot🔥/2.Cold❄️/x.이전메뉴로]:");
			KioskObject.cmd = KioskObject.sc.next();
			switch(KioskObject.cmd){
			case"1":
				Cw.wn("Hot🔥 이 선택되었습니다. 이전메뉴로 이동합니다");
				KioskObject.basket.add(new Order(KioskObject.products.get(0),1)); // 오더 추가
				break loop;
			case"2":
				Cw.wn("Ice❄️ 가 선택되었습니다. 이전메뉴로 이동합니다");
				KioskObject.basket.add(new Order(KioskObject.products.get(0),2)); // 오더 추가
				break loop;
			case"x":
				Cw.wn("이전 메뉴로 이동합니다.");
				break loop;
			}
		}
	}
}
