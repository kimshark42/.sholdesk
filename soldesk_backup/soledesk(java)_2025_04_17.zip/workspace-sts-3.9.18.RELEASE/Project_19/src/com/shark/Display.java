package com.shark;

import com.shark.c.util.So;

public class Display {
//	일반변수
	String x = "x";
	
//	static 변수
//	final 키워드를 붙이면 변수가 상수가 됨, 처음 값이 들어가면 이후 값을 못바꿈
//	상수 명명 국룰 = 이름을 전부 대문자로 씀 ex) SHARK
	
	final static String DOT = "🦈";
	
	public static void line() {
//		So.w(x); // 일반 멤버 변수는 못씀
		for(int i=0;i<32;i=i+1) {
			So.p(DOT); // static 변수는 가능함
		}
		So.In("");
	}
	public static void title() {
		line();
		So.In("🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟 따이한 수족관 🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟");
		line();
	}
}
