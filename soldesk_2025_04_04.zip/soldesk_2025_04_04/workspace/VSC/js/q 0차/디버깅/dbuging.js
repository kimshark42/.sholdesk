var a = 1;

document.write(a);

var b = 2;

document.write(b);