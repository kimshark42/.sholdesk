CREATE DATABASE dho default CHARACTER SET UTF8MB4;
use dho;
use my_cat;

/* SQL */
/* CREATE 특훈 문제 대항해 시대 */

/* 1. 항해일지 테이블 작성*/
create table sharkShipJournal(
   journalID INT PRIMARY KEY,
   mateID INT,
   startDay DATE,
   lastDay DATE
);

INSERT INTO sharkShipJournal VALUES (1,1,1900-01-01,1903-06-14),(2,3,1933-12-16,1935-04-02);

select*from sharkShipJournal;
drop table sharkShipJournal;

/* 2. 항로 테이블 작성 */
create table shipNabigetion(
   nabigetionID INT PRIMARY KEY,
   startCityID INT,
   endCityID INT,
   line INT COMMENT '단위: km'
);

INSERT INTO shipNabigetion VALUES (1,07,03,336),(2,07,55,779);

select*from shipNabigetion;
drop table shipNabigetion;

/* 3. 선원 테이블 생성 */
create table sailor(
   sailorID INT PRIMARY KEY,
   sailorName VARCHAR(50),
   shipID INT,
   sailorPosition VARCHAR(30)
);

INSERT INTO sailor VALUES (1,'김상어',33,'선장'),(2,'핫산',33,'1등 항해사');

select*from sailor;
drop table sailor;

/* 4. 무기 테이블 생성 */
create table weapon(
   weaponID INT PRIMARY KEY,
   weaponName VARCHAR(50),
   weaponAttack INT,
   weaponPrice INT
);

INSERT INTO weapon VALUES (1,'고래의 심장',50,433),(2,'마을을 지킬 작살',32,200);

select*from weapon;
drop table weapon;

/* 5. 선박 업그레이드 테이블 생성 */
create table shipUpgread(
   upgreadID INT PRIMARY KEY,
   shipID INT,
   upgreadName VARCHAR(50),
   upgreadDate DATE
);

INSERT INTO shipUpgread VALUES (1,33,'따이',1872-10-22),(2,02,'피쿼드 타운',0336-03-02);

select*from shipUpgread;
drop table shipUpgread;

/* 6. 길드원 테이블 생성 */
create table guild(
   guildPeopleID INT PRIMARY KEY,
   guildID INT,
   nabigetionSailorID INT,
   gredet DATE
);

INSERT INTO guild VALUES (1,2,3,1234-12-12),(2,3,4567,08,09);

select*from guild;
drop table guild;

/* 7. 도시 건물 테이블 생성 */
create table cityBuilding(
   buildingID INT PRIMARY KEY,
   cityID INT,
   buildingName VARCHAR(50),
   buildingFunction VARCHAR(100)
);

INSERT INTO cityBuiding VALUES (1,22,'거주구','거주'),(1,22,'둥지','둥지 내부');

select*from cityBuilding;
drop table cityBuilding;

/* 8. 거래 기록 테이블 생성 */
create table sellRecode(
   sellID INT PRIMARY KEY,
   nabigetionSaliorID INT,
   thisID INT,
   marth INT,
   sellPrice INT,
   sellDate DATE
);

INSERT INTO sellRecode VALUES (1,2,3,4,5,1234,05,06),(7,8,9,10,11,1213,01,04);

select*from sellRecode;
drop table sellRecode;

/* 9. 모험 테이블 생성 */
create table adventer(
   adventerID INT PRIMARY KEY,
   nabigetionSaliorID INT,
   adventerName VARCHAR(100),
   sussfull BOOLEAN
);

INSERT INTO adventer VALUES (1,2,'따이',TRUE),(3,4,'따이...',FALSE);

select*from adventer;
drop table adventer;

/* 10. 보물 테이블 생성(위도, 경도 추가) */
create table treasure(
   treasureID INT PRIMARY KEY,
   treasureName VARCHAR(50),
   price INT,
   cityID INT,
   latitude DECIMAL,
   longitude DECIMAL
);

INSERT INTO treasure(treasureID,treasureName,price,cityID,latitude,longitude) VALUES (1,'따이',2,3,(4,5),(6,7)),(8,'9,10',11,12,(13,14),(15,16));

select*from treasure;
drop table treasure;