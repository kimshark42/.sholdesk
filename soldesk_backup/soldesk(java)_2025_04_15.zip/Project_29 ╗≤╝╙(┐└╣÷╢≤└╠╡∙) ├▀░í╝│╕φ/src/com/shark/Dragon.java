package com.shark;

import com.shark.util.So;
import com.shark.util.Color;

public class Dragon extends Monster{
	@Override
	public Dragon(String name) {
		this.name = name; // 드래곤 이름 설정
	}
	@Override
	void attack(Player p) {
		attack = 200;
		Color.redln(String.format(" %s의 개짱썐 브레스!! %s에게 피해를 %d 주었다!",name, p.name,attack));
	}
}
