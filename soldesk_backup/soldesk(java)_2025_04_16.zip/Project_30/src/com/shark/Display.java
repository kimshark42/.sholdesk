package com.shark;

import com.shark.util.*;

public class Display {
	String x = "x";  // 일반 멤버 변수
	
	// final 키워드를 붙이면 변수가 상수가 됨, 처음에 값이 들어가면 이후 값을 못 바꿈
	// 상수 명명 국룰은 이름을 전부 대문자로 씀 ex) final static String SHARK = "🦈" <- 요런 느낌
	// staric 변수는 Display(변수를 만든 클래스명).SHARK(변수명) 이런식으로 따로 객체 생성 없이 아무대서나 사용 가능
	// > 같은 식구 ex) line()들은 그냥 DOT 이라고 쓸수 있음
	final static String DOT = "🦈";
	final static int DOT_COUNT = 47;
	public static void line() {  // static 함수 Display(변수를 만든 클래스명).line() 이런식으로 객체 생성 없이 아무데서나 사용 가능
//		Cw.w(x);  // static 함수 내에는 일만 멤버 변수는 쓸수 없음
		for(int i=0;i<DOT_COUNT;i=i+1) {
			Color.sum(Color.BLUE, DOT);  // 하지만 static 멤버 변수는 사용 가능하다
		}
//		Cw 클래스에 썼던거 -> 엔터쳐주는 함수
		Cw.wn();
	}
	public static void title() {
		line();
		dot(10);
		Color.sum(Color.BRIGHT_BLUE,("따이한 수족관 (v."+Kiosk.VERSION+" by kim.shark)"));
		dot(10);
		Cw.wn();
		line();
	}
	public static void dot(int n) {
		for(int i=0;i<n;i++) { // i++ 는 i=i+1을 줄여쓴거 하도 쓰니깐 저런식으로 쓴거임
		}
	}
}
