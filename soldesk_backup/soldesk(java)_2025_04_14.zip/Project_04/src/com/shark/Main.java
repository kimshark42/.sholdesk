package com.shark;

public class Main {

	public static void main(String[] args) {
//		java 배열은 js랑 달리 자릿수를 처음에 정해주면 더 이상 늘리거나 줄일수 없음
//		js 에서는 자릿수를 정해주지 않으면 뒤에 null 이라고 뜸
		
//		배열 선언 법 - 1. 자릿수만 잡아주는 선언 
		int n[]=new int[2];  // 0으로 초기화됨.
//		int []n=new int[2];  // 0으로 초기화됨. //[]의 위치는 방식이 두가지(개인 취향)
		System.out.println(n[1]);
		
		n[0]=1;
		n[1]=2;
		System.out.println(n[0]); // 출력 후 엔터 안하는 애
		System.out.println(n[1]); // 출력 후 엔터 하는 애
		
		String s[] = new String[2];  // null로 초기화 됨
		System.out.println(s[1]);
		s[0]="고래";
		s[1]="바부고래";
		System.out.println(s[0]);
		System.out.println(s[1]);
		
		// 배열 선언법 -2. 바로 값도 주는 선언 (방식1)
		int m[]=new int[] {1,2};
		
		System.out.println(m[0]);
		System.out.println(m[1]);
		
//		배열 선언법 -3.바로 값도 주는 선언(방식2)
		int x[]= {1,2};
		System.out.println(x[0]);
		System.out.println(x[1]);
	}

}
