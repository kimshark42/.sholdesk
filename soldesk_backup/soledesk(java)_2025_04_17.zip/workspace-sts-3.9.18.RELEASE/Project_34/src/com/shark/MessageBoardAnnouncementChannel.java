package com.shark;

import com.shark.util.Color;
import com.shark.util.Cw;

public class MessageBoardAnnouncementChannel {
	public static void run() {
		Post.messageLoad(); // 게시판 로드
		yy: while (true) {
			Color.sum(Color.BG_RED, "[📢공지]");
			Cw.wn();
			Color.sum(Color.BG_BLUE, "[1.글 목록📑/2.글 읽기📃/x.이전 메뉴❌]:");
			Post.cmd = Post.sc.next();
			switch (Post.cmd) {
			case "1":
				Color.sum(Color.BG_BLUE, "[1.글 목록📑]");
				Cw.wn();
				Post.cmd = Post.sc.next();
				break;
			case "2":
				Color.sum(Color.BG_BLUE, "[2.글 읽기📃]");
				Cw.wn();
				break;
			case "x":
				Cw.wn();
				Color.sum(Color.BRIGHT_BLACK, "❌ 이전메뉴로 돌아갑니다");
				break yy;
			}
		}
	}
}
