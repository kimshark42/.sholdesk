package com.shark;

public class Main {

	public static void main(String[] args) {
		Character shark = new Character();
		shark.name = "김상어";
//		shark.hp = "1";
		shark.info();
		
		Item book = new Item();
		book.weight = 100;
		book.name = "나인성교본";
		book.info();
		
		Sword shortSword = new Sword();
//		shortSword.name = "단검";
//		shortSword.attack = 100;
//		shortSword.weight = 10;
	}
}
