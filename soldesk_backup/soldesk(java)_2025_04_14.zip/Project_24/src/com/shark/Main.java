package com.shark;

public class Main {
	public static void main(String[] args) {		
		int currentHp = 100;
		int maxHp = 200;
		int currentMp = 50;
		int maxMp = 70;
		
		String s = String.format("[💖%4d/%4d](✨%4d/%4d)"
				,currentHp
				,maxHp
				,currentMp
				,maxMp
				);
		System.out.println(s);
	}
}
