package com.shark;

public class Shark {
	String name;
	int age;
	
/************************************************************
	생성자 함수 자동으로 생성하는법
	1. 생성자 함수를 넣을 클래스 아무곳이나 우클릭하고
	2.팝업 메뉴에서 -source- generate constructor using fields
	3.매개변수로 받을 멤버 변수 체크후 generate 버튼 클릭. 끝
************************************************************/
	public Shark(String name,int age){
		this.name = name;
		this.age = age;
	}
}
