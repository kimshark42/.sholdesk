package com.shark.channel;

public class FreeBoard extends Channel{
	public FreeBoard(String xx, int yy) {
		super(xx, yy);
	}
}
