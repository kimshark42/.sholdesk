package com.shark;

public class Item extends GameObject {
//	String name;
	int weight;
	int life;
}
