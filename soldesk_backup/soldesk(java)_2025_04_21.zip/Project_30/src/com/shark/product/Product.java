package com.shark.product;

public class Product {
	// 1. 변수들
	
	// public, private는 직접 작성하지 않으면(공란으로 비워두면) defult가 적용됨
	// protected
	public String name;
	public int price;
	
	public Product(String xx, int yy) {
		name = xx;
		price = yy;
	}
	
	// 2. 함수들(메인말고)
	void info() {
		System.out.println("상품명: "+name+"가격: "+price);
	}
}
