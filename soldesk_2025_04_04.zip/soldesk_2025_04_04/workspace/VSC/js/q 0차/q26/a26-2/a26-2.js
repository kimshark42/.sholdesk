// 함수

// 변수

//전역변수, global. 인싸변수
//지역변수, local. 아싸변수

var a;
var t;
var n;
var s;

//함수 선언(만들기)
function xx(){
    a = "4살";
    t = "스쿠알레상어목"
    n = "김상어"

    word_plus();
    alert(s);
}

function wrod_plus(){
    s = a + t + n;
}

//함수 사용, 실행, 호출
xx();