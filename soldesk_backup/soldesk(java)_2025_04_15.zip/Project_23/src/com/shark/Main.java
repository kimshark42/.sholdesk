package com.shark;

public class Main {
	public static void main(String[]ages) {
		Kiosk k = new Kiosk();
		k.run();
	}
}
