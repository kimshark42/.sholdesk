package com.shark;

import com.shark.util.Cw.*;

public class ProductMenuDessert {
	public static void run() {
		for(Product p:KioskObject.products) { // 메뉴 출력
			Cw.wn(p.name);
		}
		yy:
		while(true) {
			Cw.wn("[1.징어먹물 와플/x.이전메뉴로]");
			KioskObject.cmd = KioskObject.sc.next();
			switch(KioskObject.cmd) {
			case"1":
				Cw.wn(KioskObject.products.get(2).name+"이 선택되었습니다");
				//오더 추가
				KioskObject.basket.add(new Order(KioskObject.products.get(2)));
				break;
			case"x":
				Cw.wn("이전 메뉴로 이동합니다");
				break yy;
			}
		}
	}
}
