package com.shark;

import java.util.ArrayList;
import java.util.Scanner;

//product.* <- .*의 의미는 ~com.~ 의 하위 클래스를 전부 쓰겠다는 의미
import com.shark.product.*;

public class KioskObject {
	public static ArrayList<Order> basket = new ArrayList<>();
	public static ArrayList<Product> products = new ArrayList<>();
	public static Scanner sc = new Scanner(System.in);
	public static String cmd;
	
	public static void productLoad() {
		products.add(new Drink("상어 소다🦈",500));  // 상품 목록처리
		products.add(new Drink("고래상어 에이드🐋",1500));  // 상품 목록처리
		products.add(new Drink("바부고래 아포카토🐳",2500));  // 상품 목록처리
		products.add(new Dessert("징오징오먹물 와플🦑",2000));  // 상품 목록처리
		products.add(new Item("존1나 따이한 상어 키링💝",500));  // 상품 목록처리
	}
}
