package com.shark;

import java.util.ArrayList;
import java.util.Scanner;

import com.shark.product.Dessert;
import com.shark.product.Drink;
import com.shark.product.Product;

public class KioskObject {
	public static ArrayList<Order> basket = new ArrayList<>();  // 주문들
	public static ArrayList<Product> products = new ArrayList<>(); // 상품들
	public static Scanner sc = new Scanner(System.in);
	public static String cmd;
	
	public static void productLoad() {
		products.add(new Drink("상어 소다",500));  // 상품 목록 처리
		products.add(new Drink("고래상어 에이드",1500));  // 상품 목록 처리
		products.add(new Drink("바부고래 아포카토",2000));  // 상품 목록 처리
		products.add(new Dessert("징오징오먹물 와플",2500));  // 상품 목록 처리
//		products.add(new Merchandise("개 따이한 상어 피규어",3000));  // 상품 목록 처리
	}

}
