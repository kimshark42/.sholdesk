package com.shark;

import java.util.ArrayList;
import java.util.Scanner;
import com.shark.util.Cw;

public class Kiosk {
	public static final String VERSION = "0.1.0";  // 버전 표시용
	
	void run() {
		// test
		Cw.wn(String.format("%10s", "상어"));
		
		KioskObject.productLoad(); // 상품 로드
		Display.title();
		xx:
		while(true) {
			Cw.wn("명령 입력[1.음료 선택/2.디저트 선택/e.프로그램 종료]:");
			KioskObject.cmd = KioskObject.sc.next();
			switch(KioskObject.cmd) {
			case"1":
				ProductMenuDrink.run();
			case"2":
				ProductMenuDessert.run();
			case"e":
				Cw.wn("장바구니에 담긴 상품 갯수: "+KioskObject.basket.size());
				int sum = 0;
				for(Order o:KioskObject.basket) {  // 향상된 for문(for-each)으로 적용
					sum = sum + o.selectedProduct.price;
				}
				Cw.wn("계산하실 금액은 : "+sum+"안 입니다.");
			}
		}
	}
}
