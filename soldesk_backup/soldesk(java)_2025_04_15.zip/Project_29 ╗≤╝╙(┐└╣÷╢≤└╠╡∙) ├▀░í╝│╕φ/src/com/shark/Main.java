package com.shark;

import java.util.ArrayList;

import com.shark.util.So;

public class Main {
	public static void main(String[] args) {
		Player p = new Player("김상어",1000);
		
		ArrayList<Monster> ms = new ArrayList<>();
		ms.add(new Dragon());
		ms.add(new Dragon());
		ms.add(new Dragon());
		ms.add(new Slime());
		ms.add(new Slime());
		ms.add(new Slime());
		ms.add(new Slime());
		ms.add(new Mimic());
		ms.add(new Mimic());
		ms.add(new Mimic());
		ms.add(new Mimic());
		ms.add(new Mimic());
		
		for(Monster m : ms) {
			m.attack(p);
		}
	}
}
