package com.shark;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		System.out.println("가위바위보 중에 하나 입력해주세요:");
		
		// Scanner -> 내장되어있는 클래스
		Scanner sc = new Scanner(System.in);
		
		// next 내장된 멤버변수 호출
//		.next -> 실행 대기, 무언가 입력이 될때까지
		String userRpc = sc.next();
		
		System.out.println("님이 낸것은:"+userRpc);
		
		int r = (int)(Math.random() * 3 + 1);	// 1~3 까지 랜덤하게 뽑음
		System.out.println("주사위를 굴려 "+r+"이 나왔습니다.");

//		String -> 문자열을 넣는 클래스
//		if/else, swich, while  다 js 쓰던거랑 100% 똑같음
		String comRpc = "";
		if(r == 1) {
			comRpc = "가위";
		} else if(r == 2) {
			comRpc = "바위";
		} else if(r == 3) {
			comRpc = "보";
		}
		
		System.out.println("컴퓨터가 "+comRpc+" 냈습니다.");
		
		//todo
		//결과 판정
		String result = "";

//		java에서는 왼쪽에 있는 문자열과 오른쪽에 있는 문자를 비교할때 반드시 .equals 로 해야함
//		js 에서는 == 쓰던게 java 에서는 .equals 라고 씀
		if(userRpc.equals("가위")) {
			if(comRpc.equals("가위")) {
				result="비김";
			}
			if(comRpc.equals("바위")) {
				result="짐";
			}
			if(comRpc.equals("보")) {
				result="이김";
			}
		}
		if(userRpc.equals("바위")) {
			if(comRpc.equals("가위")) {
				result="이김";
			}
			if(comRpc.equals("바위")) {
				result="비김";
			}
			if(comRpc.equals("보")) {
				result="짐";
			}
		}
		if(userRpc.equals("보")) {
			if(comRpc.equals("가위")) {
				result="짐";
			}
			if(comRpc.equals("바위")) {
				result="이김";
			}
			if(comRpc.equals("보")) {
				result="비김";
			}
		}
		System.out.println("결과:"+result);
	}
}