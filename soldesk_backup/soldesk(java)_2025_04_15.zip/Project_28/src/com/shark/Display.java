package com.shark;

import com.shark.util.Cw;

public class Display {
	String x = "x";  // 일반 멤버 변수
	
	// final 키워드를 붙이면 변수가 상수가 됨, 처음 값이 들어가면 이후 값을 바꿀수 없음
	// 상수 명명 국룰 -> 이름을 전부 대문자로 바꿈 ex) final static String Shark = "🦈"
	//  >같은 식구 ex) line() 들은 그냥 DOT라고 쓸수 있음
	final static String DOT = "🦈";
	final static int DOT_COUNT = 47;
	public static void line() {  // static 함수 Display.line(); 이런 식으로 객체 생성 없이 아무데서나 사용 가능
//		Cw.w(x);  // 다만 일반 변수는 못씀
		for(int i=0;i<DOT_COUNT;i=i+1) {
			Cw.w(DOT);  // static 멤버변수는 사용할수 있음
		}
		Cw.wn();
	}
	public static void title() {
		line();
		dot(10);
		Cw.w(" 따이한 수족관 (v."+Kiosk.VERSION+" by kim.shark");
		dot(10);
		Cw.wn();
		line();
	}
	public static void dot(int n) {
		for(int i=0;i<n;i++) {
			Cw.w(DOT);
		}
	}
}