package com.shark;

public class Main {
	public static void main(String[] args) {
		Rps_02 rps = new Rps_02();
		rps.run();
	}
}