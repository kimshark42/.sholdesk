package com.shark;

public class Main {
	public static void main(String[] args) {
		Rps_01 r = new Rps_01();
		r.run();
	}
}