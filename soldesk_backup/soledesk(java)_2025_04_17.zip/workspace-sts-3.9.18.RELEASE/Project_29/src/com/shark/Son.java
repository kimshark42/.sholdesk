package com.shark;

public class Son extends Father {
//	@골뱅이 시리즈들을 어노테이션이라고 함. 이거 안붙여도 오버라이딩은 가능함
//	그러나 붙이면 함수명을 잘못쓰거나 한걸 에러 감지해줌  <- 쓰면 좋다
	@Override void kimchi() {
		super.kimchi();  // <- 참고로 이거쓰면 부모 함수 고대로 실행해라 라는 뜻
		System.out.println("치즈김치");
	}
}
