package com.shark;

import com.shark.util.So;

public class Slime extends Monster{
	@Override
	public Slime(String name) {
		this.name = name;  // 슬라임 이름 설정
	}
	@Override
	void attack(Player p) {
		attack = 2;
		Color.blueln(String.format("%s의 몸통박치기!! %s는 %d의 피해를 받았다!",name, p.name,attack));
	}
}
