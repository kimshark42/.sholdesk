package com.shark;

import com.shark.util.Color;
import com.shark.util.So;

public class Slime extends Monster{
	public Slime(String name) {
		this.name = name;  // 네임드 슬라임 이름 설정
	}
	public Slime() {
	}
	@Override
	void attack(Player p) {
		attack = 2;
		Color.sum(Color.BLUE,(String.format("%s의 몸통박치기!! %s는 %d의 피해를 받았다!",name, p.name,attack)));
	}
}
