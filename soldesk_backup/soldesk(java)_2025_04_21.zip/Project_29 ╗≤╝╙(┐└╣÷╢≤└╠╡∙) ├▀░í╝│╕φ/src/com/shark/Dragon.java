package com.shark;

import com.shark.util.So;
import com.shark.util.Color;

public class Dragon extends Monster{
	public Dragon(String name) {
		this.name = name; // 네임드 드래곤 이름 설정
	}
	// 일반적인 빈 생성자 객체를 만들때는 안해도 되는데 따로 준비를 해놓은게 하나 있으면 수동으로 이걸 만들어 줘야함
	public Dragon() {
	}
	
	@Override
	void attack(Player p) {
		attack = 200;
		Color.sum(Color.RED,(String.format(" %s의 개짱썐 브레스!! %s에게 피해를 %d 주었다!",name, p.name,attack)));
//		일반적으로 쓰는 방법
//		Color.sum(Color.BLUE,"shark");
	}
}
