package com.shark;

public class Main {
	public static void main(String[]args) {
		Kiosk k = new Kiosk();
		k.run();
	}
}
//4. 숫자 콤마처리
//import java.text.DecimlFormat; <- 이거 넣어야됨 java 내부 함수 넣는거라
//DecimalFormat df = new DecimalFormat("#,###");
//System.out.println(df.format(n));
//Cw.w(df.format(10000));