package com.shark;

public class Item extends GameObject {
	int weight; // 무게
	int life; // 내구도
	Item(String name,int grade,int weight,int life){
		super(name, grade);
		this.weight = weight;
		this.life = life;
	}
}
