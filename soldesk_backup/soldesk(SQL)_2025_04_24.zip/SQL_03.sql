use my_cat;

drop table member;
select * from member;

create table member(
n int primary key auto_increment,
id char(50) unique not null,
name char(50) not null,
age int not null,
gender char(2) not null,
tel char(20) not null,
hobby char(50) null
);

insert into member (id,name,age,gender,tel,hobby) values('shark1','김상어',5,'따이','010-1234-1234',null);
insert into member (id,name,age,gender,tel,hobby) values('shark2','고래상어',4,'남','010-1234-1234',null);
insert into member (id,name,age,gender,tel,hobby) values('shark3','청새치',9,'남','010-1234-1234',null);