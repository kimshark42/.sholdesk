package com.shark;

import com.shark.util.Cw.*;

public class Kiosk {
	void run() {
		KioskObject.productLoad();
		Display.title();
		xx:
		while(true) {
			Cw.wn("명령 입력[1.음료 선택/2.디저트 선택/e.프로그램 종료]:");
			KioskObject.cmd = KioskObject.sc.next();
			switch(KioskObject.cmd) {
			case"1":
				ProductMenuDrink.run();
				break;
			case"2":
				ProductMenuDrink.run();
				break;
			case"e":
				Cw.wn("장바구니에 담긴 상품 갯수:"+KioskObject.basket.size());
				int sum = 0;
				for(Order o:KioskObject.basket) {
					sum = sum + o.selectedProduct.price;
				}
				Cw.wn("계산하실 금액은 :"+sum+"안 입니다");
				
				Cw.wn("🐟🦈🐟🦈🐟🦈🐟🦈🐟🦈🐟🦈🐟🦈🐟🦈");
				for(Order o:KioskObject.basket) {
					Cw.wn(o.selectedProduct.name);
				}
				Cw.wn("🐟🦈🐟🦈🐟🦈🐟🦈🐟🦈🐟🦈🐟🦈🐟🦈");
				Cw.wn("프로그램을 종료합니다");
				break xx;
			}
		}
	}
}
