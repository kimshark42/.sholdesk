use my_cat;

desc tottenham_squad;  -- 이건 뭔지 모르겠음

/* 이름에 "스" 가 들어간 선수만 선택해서 보여주기 */
select * from tottenham_squad where p_name like '%스%';  -- select*from ~ 테이블 선택, where -> 어떤 변수에서 고를지, like~ -> 뒤에 오는 변수가 포함된
/* 번호가 6 이상이면서 이름에 "제" 가 들어간 선수들만 출력 */
select * from tottenham_squad where p_name like '%제%' and p_number > 6;
/* 선수단 정보중에 특정 이름이 들어간 사람을 출력 */
select * from tottenham_squad where name like '%손%' union select * from tottenham_squad where name like '%케%';  -- union -> 뒷 문장도 해주세요 라는 코드
/* #공격수만 골라서 보여주기 */
select * from tottenham_squad where p_position = '공격수';
/* 7번 선수만 테이블에서 삭제하기 */
delete from tottenham_squad where p_number = 7;
/* 특정 번호의 선수 이름을 수정하기*/
update tottenham_squad set p_name = '로드리고밴탄쿠르' where p_number=30; -- where 필수 아니면 모든 변수의 이름이 바뀌여버림
/* 번호가 7번 이상인 선수들만 출력하기 */
select * from tottenham_squad where p_number >= 7;  -- 당연하게도 <= 7번 이하나 =7번만이나 >7 초과, <7미만도 가능하다

/* 선수단 목록을 p_number 순으로 정렬 */
select * from tottenham_squad order by p_number;  -- 기본적으로는 오름차순
select * from tottenham_squad order by p_number asc;  -- asc -> 내림차순
select * from tottenham_squad order by p_number desc;  -- desc -> 오름차순

/* 선수 목록 정렬, 키/몸무게순 같은 키일경우 몸무게가 가벼운 선수 먼저 나오기 */
select * from tottenham_squad order by p_height desc, p_weight;

/* 선수단 테이블에 새로운 멤버변수(주급)을 추가하기 */
ALTER TABLE tottenham_squad ADD weekly_pay int;  -- > 기본값이 없는 버젼
ALTER TABLE tottenham_squad ADD weekly_pay int default 0;  -- > 기본값을 준 버젼 (default 로 0을 줬음)

/* 몇몇 선수 데이터에 주급 정보 임의로 수정 */
update tottenham_squad set weekly_pay = 1000 where p_number=9;
/* 선수단 목록을 주급 순으로 정렬 */
select * from tottenham_squad order by weekly_pay desc;


/* My_SLQ 가 아니라 오라클용 소스 코드 */
/* .id 칼럼 추가 */
/* ALTER TABLE tottenham_squad add id number(5) default 0; */
/* ALTER TABLE tottenham_squad DROP COLUMN id; */
/* id가 중복 되지 않게 번호 부여하기 */
/* ALTER TABLE tottenham_squad MODIFY id number(5) PRIMARY KEY; */
desc tottenham_squad;
/* 칼럼 추가 */
/* ALTER TABLE tottenham_squad add WeeklyWage number(9) default 0 not null; */  -- 주급
/* ALTER TABLE tottenham_squad add YearlySalary number(9) default 0 not null; */  -- 연봉
ALTER TABLE tottenham_squad add injury char(1);

/* 선수단 정보 중, 등번호와 이름만 물어보기 */
select p_number,p_name from tottenham_squad;
select p_number as '등번호', P_name as '선수명' from tottenham_squad;

/* 이하 부터는 무언가를 추가해야 가능한것 같음 */
/* 동일한 주급을 받는 선수가 있게 수정 */
/* 선수단 정보 중 등번호, 이름, 주급만 뽑아 보기 */
select no,name,weeklywage as "주급" from tottenham_squad;
/* 주급을 일급으로 변경해보기 */
select no,name,weeklywage/7 일급 from tottenham_squad;
/* 소숫점 처리 */
select no,name,round(weeklywage/7) 주급 from tottenham_squad;  -- > 반올림
select no,name,floor(weeklywage/7) 주급 from tottenham_squad;  -- > 버림

/* 몇몇을 부상으로 체크 후 부상이 아닌 선수들 출력하기 */
select * from tottenham_squad where injury is null;  -- > null은 값이 아니기 때문에 = 문으로 비교 할수 없음, != 문 역시 안됨

create table tottenham_squad(                        	
	id int primary key auto_increment,
	
	p_number int,
	p_name char(50),
	p_birth date,
	p_position char(20),
	p_height int,
	p_weight int
);	

select * from tottenham_squad;
select count(*) from tottenham_squad;

drop table tottenham_squad;

#공격수
insert into tottenham_squad values(0,22,'브레넌 존슨','2001-05-23','공격수',179,73);
insert into tottenham_squad values(0,7,'손흥민','1992-07-08','공격수',183,78);
insert into tottenham_squad values(0,63,'제이미 돈리','2005-01-03','공격수',180,80);
insert into tottenham_squad values(0,36,'알레호 벨리스','2003-09-19','공격수',187,77);
insert into tottenham_squad values(0,9,'히살리송','1997-05-10','공격수',179,71);
insert into tottenham_squad values(0,14,'이반페리시치','1989-02-02','공격수',186,77);

#미드필더
insert into tottenham_squad values(0,21,'데얀클루셰프스키','2000-04-25','미드필더',186,75);
insert into tottenham_squad values(0,19,'라이언세세뇽','2000-05-18','미드필더',178,70);
insert into tottenham_squad values(0,30,'로드리고벤탄쿠르','1997-06-26','미드필더',187,77);
insert into tottenham_squad values(0,27,'마노르 솔로몬','1999-07-24','미드필더',167,63);
insert into tottenham_squad values(0,11,'브리안 힐 살바티에라','2001-02-11','미드필더',175,60);
insert into tottenham_squad values(0,58,'야고 산티아고','2003-04-15','미드필더',180,80);
insert into tottenham_squad values(0,4,'올리버 스킵','2000-09-16','미드필더',175,70);
insert into tottenham_squad values(0,38,'이브스 비수마','1996-08-30','미드필더',182,72);
insert into tottenham_squad values(0,10,'제임스 메디슨','1996-11-23','미드필더',175,73);
insert into tottenham_squad values(0,18,'지오바니 로셀소','1996-04-09','미드필더',177,74);
insert into tottenham_squad values(0,29,'파페 마타르 사르','2002-09-14','미드필더',184,70);
insert into tottenham_squad values(0,5,'피에르 호이비에르','1995-08-05','미드필더',187,84);

#수비수
insert into tottenham_squad values(0,38,'데스티니 우도지','2002-11-28','수비수',186,80);
insert into tottenham_squad values(0,37,'미키 판 더 펜','2001-04-19','수비수',193,81);
insert into tottenham_squad values(0,33,'벤 데이비스','1993-04-24','수비수',181,76);
insert into tottenham_squad values(0,65,'알피 도링턴','2005-04-20','수비수',192,86);
insert into tottenham_squad values(0,35,'애슐리 필립스','2005-06-26','수비수',192,86);
insert into tottenham_squad values(0,15,'에릭 다이어','1994-01-15','미드필더',188,90);
insert into tottenham_squad values(0,12,'에메르송 로얄','1999-01-14','수비수',181,79);
insert into tottenham_squad values(0,17,'크리스티안 로메로','1998-04-27','수비수',185,79);
insert into tottenham_squad values(0,23,'페드로 포로','1999-09-13','수비수',173,71);

#골키퍼
insert into tottenham_squad values(0,21,'굴리엘모 비카리오','1996-10-07','골키퍼',188,83);
insert into tottenham_squad values(0,40,'브랜든 오스틴','1999-01-08','골키퍼',188,80);
insert into tottenham_squad values(0,41,'알피 화이트맨','1998-10-02','골키퍼',189,84);
insert into tottenham_squad values(0,1,'위고 요리스','1986-12-26','골키퍼',188,82);
insert into tottenham_squad values(0,20,'프레이저 포스터','1988-03-17','골키퍼',201,93);