package com.shark;

import com.shark.util.*;

public class Mimic extends Monster{
	public Mimic(String name) {
		this.name = name;  // 네임드 미믹 이름 설정
	}
	public Mimic() {
	}
	@Override
	void attack(Player p) {
		attack = 10;
		Color.sum(Color.BG_MAGENTA,(String.format("%s의 집어삼키기!! %s는 %d의 피해를 받았다!!",name, p.name,attack)));
	}
}
