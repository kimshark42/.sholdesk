package com.shark;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("========================================");
		System.out.println("================ 따이한 수족관 =============");
		System.out.println("========================================");
//		ctrl + shift + o(영문자) -> 자동 임포트 (줄정리)
		Scanner sc =new Scanner(System.in);
		String cmd;
		loop_a:
			while(true) {
				System.out.println("명령:[1.음료/2.디저트]");
				cmd = sc.next();
				switch(cmd) {
				case "1": System.out.println("1번");
					loop_b:
						while(true) {
							System.out.println("명령:[1.상어콘/2.청새치 와플/x.이전메뉴/e.프로그램 종료]");
							cmd = sc.next();
							switch(cmd) {
							case "1": System.out.println("상어콘이 1개 선택됐습니다");
							break;
							case "2": System.out.println("청새치 와플이 1개 선택됐습니다");
							break;
							case "x":
								break loop_b;
							case "e":
							break loop_a;
							}
						}
					break;
				case "2": System.out.println("2번 명령 <개발중입니다>");
				break;
				case "x":
					break loop_a;
				}
			}
		System.out.println("프로그램 종료");
	}

}
