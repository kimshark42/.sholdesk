package com.shark;

//할아버지가 다시 손자나 부모를 상속받는건 안됨, 바로 빨간줄(오류)
//public class GameObject extends Sword{

public class GameObject {
	int grade;
	String name;
	
	void info() {
		System.out.println("이름:"+name+" 등급:"+grade);
	}
	GameObject(){
		System.out.println("게임 오브젝트 생성되었음, 생성자 함수 호출됨");
	}
	
	public GameObject(String name, int grade) {
		this.name = name;
		this.grade = grade;
	}
	
	public GameObject(String name) {
		this.name = name;
	}
}
