package com.shark;

public class Post {
	String title;
	String content;
	String writer;
	int no;
	
	public Post(String title, String content, String writer, int saveNo) {
		this.title = title;
		this.content = content;
		this.writer = writer;
		no = saveNo;
	}
}
