// 엔터 치는걸 함수로 만들어 놓음
// 나중에 srcipt src="commen.js" 하나만 더 집어 넣으면 됨
// 순서가 중요하기 때문에 가능하면 맨 위에 적을것

function br(){
    document.write("<br>")
}
function hr(){
    document.write("<hr>")
}

// document.write 적어놓은거

function dw(str){
    document.write(str)
}