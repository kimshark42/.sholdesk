package com.shark;

public class Sword extends Item {
	int attack;
}
