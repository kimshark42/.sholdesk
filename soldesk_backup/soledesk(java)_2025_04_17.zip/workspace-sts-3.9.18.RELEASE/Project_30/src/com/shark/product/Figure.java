package com.shark.product;

public class Figure extends Product{
	public Figure(String xx, int yy) {
		super(xx, yy);
	}
}