package com.shark;

import com.shark.util.Color;
import com.shark.util.Cw;

public class Board {
	public static final String VERSION = "0.0.2"; // 버전 표시용
	void run() {
		// todo.
//		타이틀+버전 만들기
		Display.title();
		xx: while (true) {
			Cw.wn("[1.글쓰기/2.글읽기/3.글 리스트/4.글 수정/5.글 삭제/x.프로그램 종료]:");
			Display.cmd = Display.sc.next();
			switch (Display.cmd) {
			case "1":
				break;
			case "2":
				break;
			case "3":
				break;
			case "4":
				break;
			case "5":
				break;
			case "x":
				Color.sum(Color.BG_BLACK, "프로그램을 종료합니다.");
				break xx;
			}
		}
	}

}
