package com.shark;

import com.shark.product.*;
import com.shark.util.*;

public class ProductMenuDessert {
	public static void run() {
		for(Product p:KioskObject.products) {  // 디저트 메뉴 출력
			if(p instanceof Dessert) {  // 메뉴를 디저트 계열만 출력하도록 처리
				Color.sum(Color.BG_CYAN,p.name+"  "+p.price+"안");
			}
		}
		yy:
		while(true) {
			Cw.wn("[1.징오징오먹물 와플🦑/x.이전 메뉴로]:");
			KioskObject.cmd = KioskObject.sc.next();
			switch(KioskObject.cmd) {
			case"1":
				Color.sum(Color.BRIGHT_BLUE,KioskObject.products.get(3).name+"(이)가 선택되었습니다.");
				Order n = new Order(KioskObject.products.get(3));
//				KioskObject.basket.add(new Order(KioskObject.products.get(2)));  // 장바구니에 오더 추가
				KioskObject.basket.add(n);  // 장바구니에 오더 추가, 윗 코드를 간략화 한것
				break;
			case"x":
				Cw.wn("이전 메뉴로 돌아갑니다.");
				break yy;		
			}
		}
	}
}