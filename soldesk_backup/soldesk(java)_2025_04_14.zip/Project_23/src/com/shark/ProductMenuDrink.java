package com.shark;

import com.shark.util.Cw.*;

public class ProductMenuDrink {
	public static void run() {
		for(Product p:KioskObject.products) {  // 메뉴 출력
			Cw.wn(p.name+" "+p.price+"안");
		}
		yy:
		while(true) {
			Cw.wn("[1.상어 소다/2.고래상어 에이드/3.바부고래 아포카토/x.이전메뉴로]");
			KioskObject.cmd = KioskObject.sc.next();
			switch(KioskObject.cmd) {
			case"1":
				ProductMenuOptionHotCold.run();
				break;
			case"2":
				Cw.wn(KioskObject.products.get(1).name+"이(가) 선택되었습니다");
				// 오더 추가
				KioskObject.basket.add(new Order(KioskObject.products.get(1)));
			case"3":
				Cw.wn(KioskObject.products.get(2).name+"이(가) 선택되었습니다");
				// 오더 추가
				KioskObject.basket.add(new Order(KioskObject.products.get(2)));
			case"x":
				Cw.wn("이전 메뉴로 이동합니다");
				break yy;
			}
		}
	}
}
