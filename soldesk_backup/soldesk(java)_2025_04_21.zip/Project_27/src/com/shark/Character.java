//package com.shark;
//
//public class Character extends GameObject {
////	String name;
//	int hp;
//	
//	public Character(String name,int grade,int hp) {
//		super(name,grade);
////		super 함수는 반드시 "맨 처음"에 와야함 
//		this.hp = hp;
//	}
//}