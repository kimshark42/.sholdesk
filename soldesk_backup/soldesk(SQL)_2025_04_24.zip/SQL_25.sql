use my_cat;

/* 현재시간 출력 */
select now() from dual;
select curdate() from dual;
select curtime() from dual;
select DATE_FORMAT(now(), '%Y-%m-%d %H:%i:%s') from dual;
-- 참고로 이건 형식이 정해져 있음 yyyy -> 4자리 년도, yy -> 2자리 년도, mm -> 두자리 월, H -> 24시간 형식, h -> 12시간 형식, i: 2자리 분, s: 2자리 초