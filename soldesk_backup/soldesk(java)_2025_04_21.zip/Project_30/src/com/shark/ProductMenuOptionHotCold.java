package com.shark;

import com.shark.util.*;

public class ProductMenuOptionHotCold {
	public static void run() {
		loop:
		while(true) {
			Cw.wn("[1.Hot🔥/2.Cold❄️/x.이전 메뉴로]:");
			KioskObject.cmd = KioskObject.sc.next();
			switch(KioskObject.cmd) {
			case"1":
				Color.sum(Color.BRIGHT_RED,"HOT 🔥 이(가) 선택되었습니다, 이전 메뉴로 이동합니다.");
				KioskObject.basket.add(new Order(KioskObject.products.get(0),1));
				break loop;
			case"2":
				Color.sum(Color.BRIGHT_RED,"ICE ❄️ 이(가) 선택되었습니다, 이전 메뉴로 이동합니다.");
				KioskObject.basket.add(new Order(KioskObject.products.get(0),2));
				break loop;
			case"x":
				Cw.wn("이전 메뉴로 이동합니다.");
				break loop;
			}
		}
	}
}
