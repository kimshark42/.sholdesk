package com.shark;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Main {
	public static void main(String[] args) {

//		랩퍼 클래스
		ArrayList<String> ns = new ArrayList<>();
		// 소문자로 쓰여있어서 클래스가 아님 <- 원시 자료형(또는 기본 자료형)이라고 함
		// 이런건 ArrayList 에는 넣지 못함
//		ArrayList<int> ms = new ArrayList<>();
		ArrayList<Integer> ms = new ArrayList<>();
//		이런식의 ArrayList 에 쓸수 있는 래퍼 클래스가 존재함

		// 그래서 이런것도 가능함
		Integer number = 42;
		int value = number;

		// 시간
		// 이것이자바다 p.534
		Date now = new Date(1);
//		SimpleDateFormat이라는 내부 클래스 hh 를 대문자로 쓰면 24시간 형태로 바꿔준다던지
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 hh시 mm분 ss초");
//		
		String strNow = sdf.format(now);
//		
		System.out.println(strNow);
//		
		System.out.println(now);

		// 시간 2
		// import java.util.Date;
				Calendar n = Calendar.getInstance();
				int year = n.get(Calendar.YEAR);
				int month = n.get(Calendar.MONTH) + 1;
				int day = n.get(Calendar.DAY_OF_MONTH);
				int week = n.get(Calendar.DAY_OF_WEEK);
				String strWeek = null;
				switch (week) {
				case Calendar.MONDAY:
					strWeek = "월";
					break;
				case Calendar.TUESDAY:
					strWeek = "화";
					break;
				case Calendar.WEDNESDAY:
					strWeek = "수";
					break;
				case Calendar.THURSDAY:
					strWeek = "목";
					break;
				case Calendar.FRIDAY:
					strWeek = "금";
					break;
				case Calendar.SATURDAY:
					strWeek = "토";
					break;
				default:
					strWeek = "일";
				}

				int amPm = n.get(Calendar.AM_PM);
				String strAmPm = null;
				if (amPm == Calendar.AM) {
					strAmPm = "오전";
				} else {
					strAmPm = "오후";
				}

				int hour = n.get(Calendar.HOUR);
				int minute = n.get(Calendar.MINUTE);
				int second = n.get(Calendar.SECOND);

				System.out.print(year + "년 ");
				System.out.print(month + "월 ");
				System.out.print(day + "일 ");
				System.out.print(strWeek + "요일 ");
				System.out.print(strAmPm + " ");
				System.out.print(hour + "시 ");
				System.out.print(minute + "분 ");
				System.out.print(second + "초 ");
			}
	}