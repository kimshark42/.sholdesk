package com.shark;

public class Main {

	public static void main(String[] args) {
		
		//책.193 참고
		//				리터럴.
		String shark = "상어";	// 힙동네 << "고양이" > 100번지
		//박스 = 100번지라는 주소를 담음. 단, String 형만 담을수 있음.
		
		String shark2 = "상어";	// 재활용. 위 고양이를 다시 써요. << 100
		
		if(shark == shark2) {
			System.out.println("같음");
			System.out.println(System.identityHashCode(shark));
			System.out.println(System.identityHashCode(shark2));
			//<< System.identityHashCode >> 주소 값 리턴함.
		}
		
		String whiles = new String("고래");	// 힙동네에 개 집이 지어짐		:300번지
		String whiles2 = new String("고래");	// 힙동네에 개 집이 또 지어짐		:400번지
		if(whiles == whiles2) {
			System.out.println("같음");
		} else {
			System.out.println("다름");
		}
		System.out.println(System.identityHashCode(whiles));
		System.out.println(System.identityHashCode(whiles2));
		//자바에서는 String 클래스의 멤버함수 equals 함수로 문자열이 같은지를 비교해야함. 귀찮..
		if(whiles.equals(whiles2)) {
			System.out.println("문자열 같음");
		} else {
			System.out.println("문자열 다름");
		}
	}
}