package com.shark.util;

//자주 쓰는 함수 ex) System.out.println(); 같은걸 모아두는 class
public class Cw {
	public static void w(String s) {
		System.out.println(s);
	}
	// wn 함수 - 오버로딩
	public static void wn(String s) {
		System.out.println(s);
	}
	// 그냥 엔터 하나 넣어주는 함수
	public static void  wn() {
		System.out.println();
	}
}
