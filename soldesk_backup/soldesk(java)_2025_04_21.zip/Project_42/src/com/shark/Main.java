package com.shark;

import java.util.HashMap;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		// 음식 리스트를 등록
		// 음식을 검색
		HashMap<String,Food>foods = new HashMap<>();
		
		foods.put("라면🍜",new Food("라면🍜",true,3500));
		foods.put("냉면🧊",new Food("냉면🧊",true,1500));
		foods.put("돔배기🦈",new Food("돔배기🦈",true,3500));
		foods.put("샥스핀🦈",new Food("샥스핀🦈",true,5500)); 
		
		Scanner sc = new Scanner(System.in);
		System.out.println("원하시는 음식 이름을 입력해주세요.");
		String cmd = sc.next();
		
		Food selectFood = foods.get(cmd);
		System.out.println("주문하신 음식은:"+selectFood.name);
		System.out.println("주문하신 음식은:"+selectFood.name);
		System.out.println("");
		System.out.println("Hot🔥/Cold❄️ 는:"+selectFood.isHot);
		System.out.println("가격은 :"+selectFood.price);
		
	}
}
