use shark;

drop table member;
select * from member;
create table member(
n int primary key auto_increment,
id char(50) unique not null,
name char(50) not null,
age int not null,
gender char(1) not null,
tel char(20) not null,
hobby char(50) null
);
insert into member (id,name,age,gender,tel,hobby) values('shark1','김상어',4,'따','010-1234-1234',null);
insert into member (id,name,age,gender,tel,hobby) values('shark2','청세치',99,'남','010-1234-1234',null);
insert into member (id,name,age,gender,tel,hobby) values('shark3','고래상어',32,'여','010-1234-1234',null);