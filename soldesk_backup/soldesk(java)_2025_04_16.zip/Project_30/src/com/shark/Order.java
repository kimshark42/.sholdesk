package com.shark;

import com.shark.product.Product;

public class Order {
	public Product selectedProduct;
	public int optionHotCold = 0;  //1.hot, 2.cold 뜨거운거 차가운거 고르기
	
	public Order(Product selectedProduct) {
		this.selectedProduct = selectedProduct;
	}
	public Order(Product selectedProduct, int optionHotCold) {
		this.selectedProduct = selectedProduct;
		this.optionHotCold = optionHotCold;
	}
}
