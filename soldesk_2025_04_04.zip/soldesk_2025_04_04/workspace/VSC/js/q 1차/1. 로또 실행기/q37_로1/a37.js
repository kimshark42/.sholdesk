/*************************
 로또 실행기 v0.1.0
 -컴퓨터가 45개숫자중 하나를 총 7번 뽑습니다
 ***************************/



var x = Math.floor(Math.random()*45)+1
document.write(x);
document.write("<br>")
var x1 = Math.floor(Math.random()*45)+1
document.write(x1);
document.write("<br>")
var x2 = Math.floor(Math.random()*45)+1
document.write(x2);
document.write("<br>")
var x3 = Math.floor(Math.random()*45)+1
document.write(x3);
document.write("<br>")
var x4 = Math.floor(Math.random()*45)+1
document.write(x4);
document.write("<br>")
var x5 = Math.floor(Math.random()*45)+1
document.write(x5);
document.write("<br>")
document.write("<br>")
var bounes = Math.floor(Math.random()*45)+1
document.write(bounes);
document.write("<br>")