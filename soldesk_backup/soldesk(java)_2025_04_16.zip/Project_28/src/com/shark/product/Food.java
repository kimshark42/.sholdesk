package com.shark.product;

//상속 (super)
//자식(Food)의 생성자 함수에서 부모(Product)의 생성자 호출
public class Food extends Product{
	public Food(String xx, int yy) {
		super(xx, yy);
	}
//	유통기한 적어놓은거 나중에 버전 업데이트 하면 추가할꺼
	public String expiryDate;
}
