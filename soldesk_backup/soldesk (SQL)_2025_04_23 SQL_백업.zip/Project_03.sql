use shark;


drop table sea_life;
select*from sea_life;

select*from sea_life where p_home = '따이';
delete from sea_life where p_number = 7;
update sea_life set p_name = '귀상어' where number = 6;
select*from sea_life where p_number >= 5;
select*from sea_life where p_namne like '%고래%'and p_number <= 11;

/* ALTER TABLE sea_life ADD weekly_pay INT;  -- 기본값 없이 추가 */
ALTER TABLE sea_life ADD weekly_pay INT DEFAULT 500;  -- 기본값 있이 추가 (현재 설정한것은 500원)
update sea_life set weekly_pay = 1000 where p_number=9;
select * from sea_life order by weekly_pay desc;

select*from sea_life order by p_number;
select*from sea_life order by p_number asc;
select*from sea_life order by p_number desc;

select * from sea_life order by p_height desc, p_weight;


create table sea_life(
   id int primary key auto_increment,  -- id 뒤에 오는 코드는 자동으로 숫자가 증가하게 해주는 코드
   
   p_number int,
   p_life date,  -- date 는 날짜형 코드라 yyyy-mm-dd 형식으로 넣어야함, 다만 ''를 붙이지 않으면 수식으로 계산하기 때문에 ''를 붙여야함
   p_name char(50),
   p_home char(20),
   p_heigth int,
   p_weight int
   );
   
   #따이
   insert into sea_life (p_number, p_life, p_name, p_height,p_weight)values(4,'2024-01-01','김상어','따이한곳',153,52);
   
   #상어목
   insert into sea_life values(0,70,'2024-01-02','고래상어','열대지방의 난류',1400,3000);
   insert into sea_life values(0,73,'2024-01-03','백상아리','거의 모든 바다',450,900);
   insert into sea_life values(3,28,'2024-01-28','환도상어','따이한곳',153,52);
   insert into sea_life values(4,22,'2024-01-22','얼룩수염상어','따이한곳',153,52);
   
   #상어가_아님
   insert into sea_life values(5,19,'2024-01-19','은상어','따이한곳',153,52);
   insert into sea_life values(6,22,'2024-01-22','망치상어','따이한곳',153,52);
   
   #농담
   insert into sea_life values(7,11,'2024-01-11','샤카밤바스피스','따이한곳',153,52);
   insert into sea_life values(8,29,'2024-01-29','트랄랄레로 트랄랄라','따이한곳',153,52);
   insert into sea_life values(9,35,'2024-01-04','빨판상어','따이한곳',153,52);
   insert into sea_life values(10,12,'2024-01-12','바부고래','따이한곳',153,52);
   insert into sea_life values(11,58,'2024-01-11','그린란드 상어','따이한곳',153,52);
   
   