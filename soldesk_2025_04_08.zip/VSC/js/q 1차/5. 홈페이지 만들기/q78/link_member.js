

function check(){
    alert("항목을 다 작성하지 않으셨습니다");
}