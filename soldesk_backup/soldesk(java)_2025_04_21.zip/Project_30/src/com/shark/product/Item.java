package com.shark.product;

public class Item extends Product {
	public Item(String xx, int yy) {
		super(xx, yy);
	}
}
