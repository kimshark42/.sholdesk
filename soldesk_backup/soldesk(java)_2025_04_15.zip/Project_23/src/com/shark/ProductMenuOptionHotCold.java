package com.shark;

import com.shark.util.Cw.*;

public class ProductMenuOptionHotCold {
	public static void run() {
		loop:
		while(true) {
			Cw.wn("[1.hot/2.cold/x.이전 메뉴로]");
			KioskObject.cmd = KioskObject.sc.next();
			switch(KioskObject.cmd) {
			case"1":
				Cw.wn("hot 선택됨, 이전 메뉴로 이동");
				// 오더 추가
				KioskObject.basket.add(new Order(KioskObject.products.get(0),1));
				break loop;
			case"2":
				Cw.wn("ice 선택됨, 이전 메뉴로 이동");
				// 오더 추가
				KioskObject.basket.add(new Order(KioskObject.products.get(0),2));
				break loop;
			case"x":
				Cw.wn("이전 메뉴로 이동합니다");
				break loop;
			}
		}
	}
}
