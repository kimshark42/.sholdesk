package com.shark;

import com.shark.product.*;
import com.shark.util.*;

public class ProductMenuDrink {
	public static void run() {
		for(Product p:KioskObject.products) {
			if(p instanceof Drink) {
				Color.sum(Color.BG_CYAN,p.name+"  "+p.price+"안");
			}
		}
		yy:
		while(true) {
			Cw.wn("[1.상어 소다🦈/2.고래상어 에이드🐋/3.바부고래 아포카토🐳/x.이전 메뉴로]:");
			KioskObject.cmd = KioskObject.sc.next();
			switch(KioskObject.cmd) {
			case"1":
				ProductMenuOptionHotCold.run();
				break;
			case"2":
				Color.sum(Color.BRIGHT_BLUE,KioskObject.products.get(1).name+"이(가) 선택되었습니다.");
				KioskObject.basket.add(new Order(KioskObject.products.get(1)));  // 오더 추가
				break;
			case"3":
				Color.sum(Color.BRIGHT_BLUE,KioskObject.products.get(2).name+"이(가) 선택되었습니다.");
				KioskObject.basket.add(new Order(KioskObject.products.get(2)));  // 오더 추가
				break;
			case"x":
				Cw.wn("이전 메뉴로 돌아갑니다.");
				break yy;
			}
		}
	}
}
